MwhOS v7.0 - Parasitic Graphics Operating System
==================================================

说明:
  本系统大量依赖 Windows DLL (gdi32, user32, kernel32, shell32, ole32, advapi32, wininet 等),
  因此仅可在 Windows 平台上运行, 不可移植到 Linux/macOS 等其他平台。

目录结构:
  bootsys/
  ├── kernel/      ← 系统内核 (事件、IO、内存、进程)
  ├── mwh/         ← 图形引擎 (GDI TrueType 渲染, 支持中文)
  ├── security/    ← 安全防护
  ├── asm/         ← 汇编底层 (C stubs 实现)
  ├── csharp/      ← C# 上层框架
  ├── diskmount/   ← 磁盘挂载
  ├── mwhget/      ← 下载引擎 (WinINet)
  ├── math/        ← 数学引擎
  ├── homet/       ← 用户日常文件
  │   ├── Documents/
  │   ├── Downloads/
  │   ├── Pictures/
  │   └── Desktop/
  ├── config/      ← 系统配置
  ├── Logs/        ← 系统日志
  ├── Temp/        ← 临时文件
  └── apps/        ← MwhOS 应用程序 (.mwa)
      └── firefox.mwa  ← Firefox 浏览器 (默认浏览器)

v7.0 新特性:
  1. TrueType 字体渲染 - 使用 Microsoft YaHei, 完整支持中文显示
  2. Terminal 终端 - 260 条命令, 支持键盘输入, 历史记录, 光标移动
  3. Files 文件管理器 - 仿 Windows Explorer 风格, 侧边栏 + 详情列表
  4. Firefox .mwa 转换 - Firefox 浏览器已转换为 MwhOS 独家 .mwa 格式
  5. appconv.exe - EXE 到 MWA 转换工具

使用方法:
  1. 双击运行 StartSystem.exe
  2. 在桌面点击开始菜单打开 Terminal 或 Files
  3. Terminal: 输入 'help' 查看所有 260 条命令
  4. Files: 点击侧边栏快速访问, 双击文件夹进入

版权: MwhOS Project
版本: 7.0
