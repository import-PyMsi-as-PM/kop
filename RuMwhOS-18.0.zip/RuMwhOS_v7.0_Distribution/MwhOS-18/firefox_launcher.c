/*
 * MwhOS Firefox Launcher v7.0 - 64-bit Native
 * Firefox 浏览器启动器 (64位原生)
 *
 * 功能:
 *   1. 检测系统是否已安装 Firefox
 *   2. 如果已安装, 直接启动
 *   3. 如果未安装, 下载并运行 Firefox 64位安装器
 *   4. 启动 Firefox 浏览器
 *
 * 编译: x86_64-w64-mingw32-gcc -mwindows -O2 -o firefox_launcher.exe firefox_launcher.c -lwininet -lshell32
 */

#include <windows.h>
#include <shellapi.h>
#include <wininet.h>
#include <shlobj.h>
#include <stdio.h>
#include <string.h>

#define FIREFOX_DOWNLOAD_URL L"https://download.mozilla.org/?product=firefox-latest-ssl&os=win64&lang=zh-CN"
#define FIREFOX_REG_KEY L"SOFTWARE\\Mozilla\\Mozilla Firefox"
#define FIREFOX_REG_VAL L"CurrentVersion"
#define FIREFOX_REG_PATH L"PathToExe"
#define MAX_BUF 4096

/* 查找已安装的 Firefox */
static BOOL find_firefox(wchar_t* exe_path, DWORD path_len) {
    HKEY hKey;
    wchar_t version[256];
    DWORD buf_len = sizeof(version);
    DWORD type = REG_SZ;

    /* 检查 64 位注册表 */
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, FIREFOX_REG_KEY, 0, KEY_READ | KEY_WOW64_64KEY, &hKey) == ERROR_SUCCESS) {
        if (RegQueryValueExW(hKey, FIREFOX_REG_VAL, NULL, &type, (LPBYTE)version, &buf_len) == ERROR_SUCCESS) {
            RegCloseKey(hKey);

            /* 构建完整路径键 */
            wchar_t path_key[512];
            _snwprintf(path_key, 512, L"%s\\%s\\Main", FIREFOX_REG_KEY, version);

            if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, path_key, 0, KEY_READ | KEY_WOW64_64KEY, &hKey) == ERROR_SUCCESS) {
                buf_len = path_len * sizeof(wchar_t);
                if (RegQueryValueExW(hKey, FIREFOX_REG_PATH, NULL, &type, (LPBYTE)exe_path, &buf_len) == ERROR_SUCCESS) {
                    RegCloseKey(hKey);
                    return TRUE;
                }
                RegCloseKey(hKey);
            }
        } else {
            RegCloseKey(hKey);
        }
    }

    /* 检查 32 位注册表 */
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, FIREFOX_REG_KEY, 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        if (RegQueryValueExW(hKey, FIREFOX_REG_VAL, NULL, &type, (LPBYTE)version, &buf_len) == ERROR_SUCCESS) {
            RegCloseKey(hKey);

            wchar_t path_key[512];
            _snwprintf(path_key, 512, L"%s\\%s\\Main", FIREFOX_REG_KEY, version);

            if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, path_key, 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
                buf_len = path_len * sizeof(wchar_t);
                if (RegQueryValueExW(hKey, FIREFOX_REG_PATH, NULL, &type, (LPBYTE)exe_path, &buf_len) == ERROR_SUCCESS) {
                    RegCloseKey(hKey);
                    return TRUE;
                }
                RegCloseKey(hKey);
            }
        } else {
            RegCloseKey(hKey);
        }
    }

    /* 检查用户注册表 (HKCU) */
    if (RegOpenKeyExW(HKEY_CURRENT_USER, FIREFOX_REG_KEY, 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        if (RegQueryValueExW(hKey, FIREFOX_REG_VAL, NULL, &type, (LPBYTE)version, &buf_len) == ERROR_SUCCESS) {
            RegCloseKey(hKey);

            wchar_t path_key[512];
            _snwprintf(path_key, 512, L"%s\\%s\\Main", FIREFOX_REG_KEY, version);

            if (RegOpenKeyExW(HKEY_CURRENT_USER, path_key, 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
                buf_len = path_len * sizeof(wchar_t);
                if (RegQueryValueExW(hKey, FIREFOX_REG_PATH, NULL, &type, (LPBYTE)exe_path, &buf_len) == ERROR_SUCCESS) {
                    RegCloseKey(hKey);
                    return TRUE;
                }
                RegCloseKey(hKey);
            }
        } else {
            RegCloseKey(hKey);
        }
    }

    /* 检查常见路径 */
    const wchar_t* common_paths[] = {
        L"C:\\Program Files\\Mozilla Firefox\\firefox.exe",
        L"C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe",
        NULL
    };

    for (int i = 0; common_paths[i]; i++) {
        if (GetFileAttributesW(common_paths[i]) != INVALID_FILE_ATTRIBUTES) {
            wcsncpy(exe_path, common_paths[i], path_len);
            return TRUE;
        }
    }

    return FALSE;
}

/* 下载文件 */
static BOOL download_file(const wchar_t* url, const wchar_t* dest_path) {
    HINTERNET hSession, hConnect, hRequest;
    DWORD bytes_read, total_read = 0;
    HANDLE hFile;
    char buffer[16384];
    wchar_t hostname[256] = {0};
    wchar_t path[2048] = {0};
    URL_COMPONENTSW urlComp = {0};
    BOOL result = FALSE;

    urlComp.dwStructSize = sizeof(urlComp);
    urlComp.lpszHostName = hostname;
    urlComp.dwHostNameLength = 256;
    urlComp.lpszUrlPath = path;
    urlComp.dwUrlPathLength = 2048;

    if (!InternetCrackUrlW(url, wcslen(url), 0, &urlComp)) {
        MessageBoxW(NULL, L"URL解析失败", L"Firefox Launcher", MB_ICONERROR);
        return FALSE;
    }

    hSession = InternetOpenW(L"MwhOS Firefox Launcher 7.0",
                             INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    if (!hSession) return FALSE;

    hConnect = InternetConnectW(hSession, hostname,
                                urlComp.nPort ? urlComp.nPort : INTERNET_DEFAULT_HTTPS_PORT,
                                NULL, NULL, INTERNET_SERVICE_HTTP,
                                0, 0);
    if (!hConnect) {
        InternetCloseHandle(hSession);
        return FALSE;
    }

    DWORD flags = INTERNET_FLAG_SECURE | INTERNET_FLAG_RELOAD;
    hRequest = HttpOpenRequestW(hConnect, L"GET", path, NULL, NULL, NULL, flags, 0);
    if (!hRequest) {
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hSession);
        return FALSE;
    }

    if (!HttpSendRequestW(hRequest, NULL, 0, NULL, 0)) {
        InternetCloseHandle(hRequest);
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hSession);
        MessageBoxW(NULL, L"无法连接到下载服务器", L"Firefox Launcher", MB_ICONERROR);
        return FALSE;
    }

    /* 检查重定向 */
    DWORD status_code = 0;
    DWORD status_len = sizeof(status_code);
    HttpQueryInfoW(hRequest, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                   &status_code, &status_len, NULL);

    if (status_code == 302 || status_code == 301) {
        wchar_t new_url[2048] = {0};
        DWORD url_len = sizeof(new_url);
        if (HttpQueryInfoW(hRequest, HTTP_QUERY_LOCATION, new_url, &url_len, NULL)) {
            InternetCloseHandle(hRequest);
            InternetCloseHandle(hConnect);
            InternetCloseHandle(hSession);
            return download_file(new_url, dest_path);
        }
    }

    if (status_code != 200) {
        InternetCloseHandle(hRequest);
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hSession);
        return FALSE;
    }

    hFile = CreateFileW(dest_path, GENERIC_WRITE, 0, NULL,
                        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        InternetCloseHandle(hRequest);
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hSession);
        return FALSE;
    }

    while (InternetReadFile(hRequest, buffer, sizeof(buffer), &bytes_read) && bytes_read > 0) {
        DWORD written;
        WriteFile(hFile, buffer, bytes_read, &written, NULL);
        total_read += bytes_read;
    }

    CloseHandle(hFile);
    InternetCloseHandle(hRequest);
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hSession);

    result = (total_read > 0);
    return result;
}

/* 获取临时文件路径 */
static void get_temp_path(wchar_t* path, DWORD len) {
    GetTempPathW(len, path);
    wcscat(path, L"MwhOS_Firefox_Setup.exe");
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPWSTR lpCmdLine, int nShow) {
    wchar_t firefox_path[MAX_PATH] = {0};

    /* 1. 先查找已安装的 Firefox */
    if (find_firefox(firefox_path, MAX_PATH)) {
        /* 直接启动 Firefox */
        HINSTANCE hInst = ShellExecuteW(NULL, L"open", firefox_path,
                                        lpCmdLine, NULL, SW_SHOWNORMAL);
        if ((intptr_t)hInst > 32) {
            return 0;
        }
    }

    /* 2. Firefox 未安装, 下载安装器 */
    int choice = MessageBoxW(NULL,
        L"未检测到 Firefox 浏览器。\n\n"
        L"是否要下载并安装 Firefox 64位?\n"
        L"(MwhOS 默认浏览器)",
        L"MwhOS Firefox Launcher v7.0",
        MB_YESNO | MB_ICONQUESTION);

    if (choice != IDYES) {
        /* 尝试用系统默认浏览器打开 */
        ShellExecuteW(NULL, L"open", L"https://www.mozilla.org/firefox/",
                      NULL, NULL, SW_SHOWNORMAL);
        return 0;
    }

    /* 3. 下载 Firefox 安装器 */
    wchar_t setup_path[MAX_PATH] = {0};
    get_temp_path(setup_path, MAX_PATH);

    MessageBoxW(NULL, L"正在下载 Firefox 64位安装包...\n请稍候。",
                L"Firefox Launcher", MB_OK | MB_ICONINFORMATION);

    if (!download_file(FIREFOX_DOWNLOAD_URL, setup_path)) {
        MessageBoxW(NULL,
                    L"下载失败!\n\n请检查网络连接后重试。\n"
                    L"或手动访问 https://www.mozilla.org/firefox/ 下载",
                    L"Firefox Launcher - 下载失败", MB_ICONERROR);
        return 1;
    }

    /* 4. 运行安装器 */
    HINSTANCE hInst = ShellExecuteW(NULL, L"open", setup_path,
                                    L"-ms",  /* 静默安装 */
                                    NULL, SW_SHOWNORMAL);
    if ((intptr_t)hInst <= 32) {
        /* 如果静默安装失败, 尝试普通模式 */
        hInst = ShellExecuteW(NULL, L"open", setup_path, NULL, NULL, SW_SHOWNORMAL);
        if ((intptr_t)hInst <= 32) {
            MessageBoxW(NULL, L"无法运行 Firefox 安装程序。",
                        L"Firefox Launcher", MB_ICONERROR);
            return 1;
        }
    }

    /* 5. 等待安装完成 */
    Sleep(3000);

    /* 6. 再次查找 Firefox */
    if (find_firefox(firefox_path, MAX_PATH)) {
        ShellExecuteW(NULL, L"open", firefox_path, lpCmdLine, NULL, SW_SHOWNORMAL);
    } else {
        MessageBoxW(NULL,
                    L"Firefox 安装完成!\n\n请重新启动 MwhOS 浏览器以打开 Firefox。",
                    L"Firefox Launcher", MB_OK | MB_ICONINFORMATION);
    }

    /* 7. 清理安装器 */
    Sleep(1000);
    DeleteFileW(setup_path);

    return 0;
}
