#!/usr/bin/env python3
"""
MwhOS MWA Converter v7.0
Converts EXE to .mwa format matching the MwhOS specification.
Format: 512-byte header + optional icon data + EXE data.
"""

import struct
import sys
import os
import time

MWA_MAGIC = b"MWHAPP\x00\x00"  # 8 bytes to match C definition
MWA_MAGIC_SIZE = 8
MWA_FORMAT_VERSION = 7
MWA_HEADER_SIZE = 512

MWA_FLAG_HAS_ICON    = 1 << 0
MWA_FLAG_COMPRESSED  = 1 << 1
MWA_FLAG_GUI_APP     = 1 << 2
MWA_FLAG_NEED_ADMIN  = 1 << 3
MWA_FLAG_NEED_MDRIVE = 1 << 4
MWA_FLAG_NEED_BROWSER = 1 << 5

def _build_crc32_table():
    table = []
    for i in range(256):
        crc = i
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xEDB88320
            else:
                crc >>= 1
        table.append(crc)
    return table

CRC32_TABLE = _build_crc32_table()

def mwa_crc32(data):
    if not data or len(data) == 0:
        return 0
    crc = 0xFFFFFFFF
    for b in data:
        crc = (crc >> 8) ^ CRC32_TABLE[(crc ^ b) & 0xFF]
    return ~crc & 0xFFFFFFFF

def convert_exe_to_mwa(exe_path, mwa_path, app_name, app_ver="1.0.0",
                       author="Unknown", desc="", category="Utilities",
                       flags=MWA_FLAG_GUI_APP):
    with open(exe_path, "rb") as f:
        exe_data = f.read()
    
    if len(exe_data) < 2 or exe_data[0:2] != b"MZ":
        print(f"Error: {exe_path} is not a valid PE/EXE file (no MZ header)")
        return False
    
    exe_size = len(exe_data)
    
    header = bytearray(MWA_HEADER_SIZE)
    header[0:8] = MWA_MAGIC
    struct.pack_into("<H", header, 8, MWA_FORMAT_VERSION)
    struct.pack_into("<H", header, 10, flags)
    
    name_bytes = app_name.encode("utf-8")[:63]
    header[12:12+len(name_bytes)] = name_bytes
    
    ver_bytes = app_ver.encode("utf-8")[:31]
    header[76:76+len(ver_bytes)] = ver_bytes
    
    author_bytes = author.encode("utf-8")[:31]
    header[108:108+len(author_bytes)] = author_bytes
    
    desc_bytes = desc.encode("utf-8")[:127]
    header[140:140+len(desc_bytes)] = desc_bytes
    
    cat_bytes = category.encode("utf-8")[:31]
    header[268:268+len(cat_bytes)] = cat_bytes
    
    struct.pack_into("<Q", header, 300, 0)  # icon offset
    struct.pack_into("<Q", header, 308, 0)  # icon size
    struct.pack_into("<Q", header, 316, MWA_HEADER_SIZE)  # exe offset
    struct.pack_into("<Q", header, 324, exe_size)
    struct.pack_into("<Q", header, 332, exe_size)  # compressed = uncompressed
    struct.pack_into("<Q", header, 340, int(time.time()))
    struct.pack_into("<I", header, 348, 700)  # min MwhOS version
    
    checksum_buf = bytearray()
    checksum_buf += header[:352]
    checksum_buf += header[356:512]
    checksum_buf += exe_data
    
    checksum = mwa_crc32(bytes(checksum_buf))
    struct.pack_into("<I", header, 352, checksum)
    
    with open(mwa_path, "wb") as f:
        f.write(bytes(header))
        f.write(exe_data)
    
    print(f"Conversion successful!")
    print(f"  Input:  {exe_path} ({exe_size} bytes)")
    print(f"  Output: {mwa_path} ({MWA_HEADER_SIZE + exe_size} bytes)")
    print(f"  Name:   {app_name}")
    print(f"  Ver:    {app_ver}")
    print(f"  CRC32:  0x{checksum:08X}")
    return True

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: mwa_convert.py <input.exe> <output.mwa> [name] [version]")
        sys.exit(1)
    
    exe_path = sys.argv[1]
    mwa_path = sys.argv[2]
    name = sys.argv[3] if len(sys.argv) > 3 else "Application"
    version = sys.argv[4] if len(sys.argv) > 4 else "1.0.0"
    
    convert_exe_to_mwa(exe_path, mwa_path, name, version)
